let items = [
  {
    id: 0,
    name: "Apple iPad Mini 2 16GB",
    description: "An iPad like no other. 16GB, WiFi, 4G.",
    price: 229.00
  },
  {
    id: 1,
    name: "Apple iPad Mini 2 32GB",
    description: "Even larger than the 16GB.",
    price: 279.00
  },
  {
    id: 2,
    name: "Canon T7i",
    description: "DSLR camera with lots of megapixels.",
    price: 749.99
  },
  {
    id: 3,
    name: "Apple Watch Sport",
    description: "A watch",
    price: 249.99
  },
  {
    id: 4,
    name: "Apple Watch Silver",
    description: "A more expensive watch",
    price: 599.99
  }
];

export {items};

