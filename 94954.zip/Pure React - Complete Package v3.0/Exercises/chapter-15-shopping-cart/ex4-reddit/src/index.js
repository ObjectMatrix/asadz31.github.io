import React from 'react';
import ReactDOM from 'react-dom';
import Reddit from './Reddit';
import './index.css';

ReactDOM.render(
    <Reddit/>,
    document.querySelector('#root')
);
